import axios, { AxiosError } from 'axios';
import { toast } from 'react-hot-toast';

const MAX_RETRIES = 3;
const RETRY_DELAY = 1000;

const api = axios.create({
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000, // 10 seconds
  withCredentials: true,
});

// Retry failed requests
const retryRequest = async (error: AxiosError, retryCount: number = 0): Promise<any> => {
  const shouldRetry = retryCount < MAX_RETRIES && 
    (error.code === 'ECONNABORTED' || 
     error.response?.status === 408 || 
     error.response?.status === 429 ||
     !error.response);

  if (shouldRetry) {
    await new Promise(resolve => setTimeout(resolve, RETRY_DELAY * (retryCount + 1)));
    const config = error.config;
    return api.request(config).catch(err => retryRequest(err, retryCount + 1));
  }

  return Promise.reject(error);
};

// Request interceptor
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    console.error('Request error:', error);
    return Promise.reject(error);
  }
);

// Response interceptor
api.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    if (!error.response) {
      toast.error('Network error. Please check your connection.');
      return retryRequest(error);
    }

    switch (error.response.status) {
      case 401:
        localStorage.removeItem('token');
        window.location.href = '/login';
        break;
      case 403:
        toast.error('You do not have permission to perform this action');
        break;
      case 404:
        toast.error('Resource not found');
        break;
      case 429:
        toast.error('Too many requests. Please try again later.');
        return retryRequest(error);
      case 500:
        toast.error('Server error. Please try again later.');
        break;
      default:
        toast.error(error.response.data?.message || 'An error occurred');
    }

    return Promise.reject(error);
  }
);

const handleApiError = (error: any) => {
  if (error.response?.data?.message) {
    return Promise.reject(new Error(error.response.data.message));
  }
  return Promise.reject(error);
};

export const authAPI = {
  login: async (email: string, password: string) => {
    try {
      const response = await api.post('/auth/login', { email, password });
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },

  register: async (name: string, email: string, password: string, role: string) => {
    try {
      const response = await api.post('/auth/register', { name, email, password, role });
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },

  logout: async () => {
    try {
      const response = await api.post('/auth/logout');
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },

  getProfile: async () => {
    try {
      const response = await api.get('/auth/profile');
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },
};

export const assessmentAPI = {
  getAll: async () => {
    try {
      const response = await api.get('/assessments');
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },

  getById: async (id: string) => {
    try {
      const response = await api.get(`/assessments/${id}`);
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },

  create: async (data: any) => {
    try {
      const response = await api.post('/assessments', data);
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },

  update: async (id: string, data: any) => {
    try {
      const response = await api.put(`/assessments/${id}`, data);
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },

  delete: async (id: string) => {
    try {
      const response = await api.delete(`/assessments/${id}`);
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },

  submitResponse: async (id: string, data: any) => {
    try {
      const response = await api.post(`/assessments/${id}/submit`, data);
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },
};

export const userAPI = {
  getProgress: async () => {
    try {
      const response = await api.get('/users/progress');
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },

  getCertificates: async () => {
    try {
      const response = await api.get('/users/certificates');
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },

  getBadges: async () => {
    try {
      const response = await api.get('/users/badges');
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },

  updateProfile: async (data: any) => {
    try {
      const response = await api.put('/users/profile', data);
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },
};

export const analyticsAPI = {
  getAssessmentStats: async (id: string) => {
    try {
      const response = await api.get(`/analytics/assessments/${id}`);
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },

  getUserStats: async () => {
    try {
      const response = await api.get('/analytics/user');
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },

  getOverallStats: async () => {
    try {
      const response = await api.get('/analytics/overall');
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },
};

export const discussionAPI = {
  getTopics: async () => {
    try {
      const response = await api.get('/discussions');
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },

  createTopic: async (data: any) => {
    try {
      const response = await api.post('/discussions', data);
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },

  addReply: async (topicId: string, data: any) => {
    try {
      const response = await api.post(`/discussions/${topicId}/replies`, data);
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },
};

export default api;