import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Clock, AlertCircle, CheckCircle, Award } from 'lucide-react';
import { useAccessibility } from '../context/AccessibilityContext'; // Import accessibility context
import type { Assessment } from '../types';

interface Question {
  id: number;
  text: string;
  options: string[];
  correctAnswer: number;
}

function AssessmentPage() {
  const navigate = useNavigate();
  const { 
    isKeyboardNavigationEnabled, 
    isExtendedTimeEnabled,
    isScreenReaderEnabled,
    textToSpeech 
  } = useAccessibility(); // Access the context

  const [stage, setStage] = useState<'instructions' | 'exam' | 'result'>('instructions');
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [timeLeft, setTimeLeft] = useState(3600); // 60 minutes

  const dummyQuestions: Question[] = [
    {
      id: 1,
      text: "What is the primary purpose of React's useEffect hook?",
      options: [
        "To handle side effects in functional components",
        "To create new components",
        "To style components",
        "To handle routing"
      ],
      correctAnswer: 0
    },
    {
      id: 2,
      text: "Which hook is used for managing local state in React?",
      options: [
        "useLocal",
        "useState",
        "useState()",
        "useLocalState"
      ],
      correctAnswer: 1
    },
    // Add more questions as needed
  ];

  useEffect(() => {
    if (isKeyboardNavigationEnabled) {
      // Add keyboard navigation handlers
      const handleKeyNav = (e: KeyboardEvent) => {
        if (e.key === 'Enter' || e.key === ' ') {
          const activeElement = document.activeElement as HTMLElement;
          activeElement?.click();
        }
      };
      
      document.addEventListener('keydown', handleKeyNav);
      return () => document.removeEventListener('keydown', handleKeyNav);
    }
  }, [isKeyboardNavigationEnabled]);

  const handleStartExam = () => {
    setStage('exam');
    // Start timer
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setStage('result');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleAnswer = (answerIndex: number) => {
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = answerIndex;
    setAnswers(newAnswers);

    if (currentQuestion < dummyQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setStage('result');
    }
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const calculateScore = () => {
    let correct = 0;
    answers.forEach((answer, index) => {
      if (answer === dummyQuestions[index].correctAnswer) correct++;
    });
    return (correct / dummyQuestions.length) * 100;
  };

  const readQuestion = (text: string) => {
    if (isScreenReaderEnabled) {
      textToSpeech.speak(text);
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      {stage === 'instructions' && (
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6" onClick={() => readQuestion("Assessment Instructions")}>
            Assessment Instructions
          </h2>
          <div className="space-y-4 mb-8">
            <div className="flex items-start gap-3">
              <Clock className="h-6 w-6 text-indigo-600 mt-1" />
              <div>
                <h3 className="font-medium text-gray-900">Duration</h3>
                <p className="text-gray-600">60 minutes</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <AlertCircle className="h-6 w-6 text-indigo-600 mt-1" />
              <div>
                <h3 className="font-medium text-gray-900">Important Notes</h3>
                <ul className="list-disc list-inside text-gray-600 space-y-2">
                  <li>Ensure stable internet connection</li>
                  <li>Don't switch browser tabs or windows</li>
                  <li>Timer will continue even if you lose connection</li>
                  <li>Submit before time expires</li>
                </ul>
              </div>
            </div>
          </div>
          <button
            onClick={handleStartExam}
            className="w-full py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
          >
            Start Assessment
          </button>
        </div>
      )}

      {stage === 'exam' && (
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold text-gray-900">
              Question {currentQuestion + 1} of {dummyQuestions.length}
            </h2>
            <div className="text-lg font-medium text-indigo-600">
              Time Left: {formatTime(timeLeft)}
            </div>
          </div>

          <div className="mb-8">
            <p className="text-lg text-gray-900 mb-4" onClick={() => readQuestion(dummyQuestions[currentQuestion].text)}>
              {dummyQuestions[currentQuestion].text}
            </p>
            <div className="space-y-3">
              {dummyQuestions[currentQuestion].options.map((option, index) => (
                <button
                key={index}
                onClick={() => {
                  handleAnswer(index); // Handle answer selection
                  readQuestion(option); // Read the option text
                }}
                className={`w-full p-4 text-left rounded-lg border ${
                  answers[currentQuestion] === index
                    ? 'border-indigo-500 bg-indigo-50'
                    : 'border-gray-200 hover:border-indigo-500'
                }`}
                tabIndex={isKeyboardNavigationEnabled ? 0 : -1}
              >
                {option}
              </button>
              ))}
            </div>
          </div>

          <div className="flex justify-between">
            <button
              onClick={() => setCurrentQuestion(Math.max(0, currentQuestion - 1))}
              disabled={currentQuestion === 0}
              className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 disabled:opacity-50"
            >
              Previous
            </button>
            <button
              onClick={() => {
                if (currentQuestion === dummyQuestions.length - 1) {
                  setStage('result');
                } else {
                  setCurrentQuestion(currentQuestion + 1);
                }
              }}
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
            >
              {currentQuestion === dummyQuestions.length - 1 ? 'Submit' : 'Next'}
            </button>
          </div>
        </div>
      )}

      {stage === 'result' && (
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 mb-4">
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              Assessment Completed!
            </h2>
            <p className="text-gray-600">
              You've successfully completed the assessment.
            </p>
          </div>

          <div className="bg-gray-50 rounded-lg p-6 mb-8">
            <div className="grid grid-cols-2 gap-6">
              <div>
                <p className="text-sm text-gray-500">Score</p>
                <p className="text-2xl font-bold text-gray-900">{calculateScore()}%</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Time Taken</p>
                <p className="text-2xl font-bold text-gray-900">
                  {formatTime(3600 - timeLeft)}
                </p>
              </div>
            </div>
          </div>

          <div className="flex gap-4">
            <button
              onClick={() => navigate('/dashboard')}
              className="flex-1 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
            >
              Go to Dashboard
            </button>
            <button
              onClick={() => setStage('instructions')}
              className="flex-1 py-3 border border-indigo-600 text-indigo-600 rounded-lg hover:bg-indigo-50"
            >
              Retry Assessment
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default AssessmentPage;
